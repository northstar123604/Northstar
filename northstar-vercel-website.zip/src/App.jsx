import "./index.css";

export default function App() {
  const courses = [
    'Grooming',
    'Spoken English',
    'Digital Marketing',
    'Graphic Design',
    'Acting',
    'Modelling',
    'Anchoring',
    'Banking',
    'Hospitality',
    'AI Masterclass'
  ];

  return (
    <div className="bg-white text-gray-800 font-sans">
      {/* Navbar */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <img
              src="/logo.png"
              alt="Northstar Logo"
              className="h-16 w-auto"
            />
            <div>
              <h1 className="text-2xl font-extrabold text-green-900">
                Northstar
              </h1>
              <p className="text-sm text-red-600 font-medium">
                Job Excellence Academy
              </p>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-r from-green-900 via-green-800 to-red-700 text-white">
        <div className="max-w-7xl mx-auto px-6 py-20 grid md:grid-cols-2 gap-10 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-extrabold leading-tight mb-6">
              Build Skills.<br />
              Build Confidence.<br />
              Build Your Career.
            </h1>

            <p className="text-lg md:text-xl text-gray-100 mb-8 leading-relaxed">
              Northstar Job Excellence Academy empowers students and job seekers through practical training, grooming, and placement-focused learning.
            </p>

            <div className="flex flex-wrap gap-4">
              <button className="bg-yellow-400 text-black font-bold px-6 py-3 rounded-2xl shadow-lg">
                Enroll Now
              </button>

              <button className="border border-white px-6 py-3 rounded-2xl hover:bg-white hover:text-green-900 transition">
                Free Demo Class
              </button>
            </div>
          </div>

          <div>
            <img
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=1200&auto=format&fit=crop"
              alt="Students"
              className="rounded-3xl shadow-2xl"
            />
          </div>
        </div>
      </section>

      {/* Courses */}
      <section className="bg-gray-50 py-20 px-6">
        <div className="max-w-7xl mx-auto text-center">
          <h2 className="text-4xl font-bold mt-3 text-green-900 mb-12">
            Explore Career-Oriented Programs
          </h2>

          <div className="grid sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {courses.map((course, i) => (
              <div
                key={i}
                className="bg-white rounded-3xl p-6 shadow-lg"
              >
                <div className="text-4xl mb-4">🎓</div>
                <h3 className="font-bold text-lg text-green-900">{course}</h3>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Registration Form */}
      <section className="py-20 px-6 bg-white">
        <div className="max-w-5xl mx-auto bg-gradient-to-r from-green-900 to-red-700 rounded-3xl p-10 shadow-2xl text-white">
          <div className="text-center mb-10">
            <h2 className="text-5xl font-bold mb-4">Register Now</h2>
            <p className="text-lg text-gray-100">
              Fill out the form and our team will contact you soon.
            </p>
          </div>

          <form className="grid md:grid-cols-2 gap-6">
            <input
              type="text"
              placeholder="Full Name"
              className="p-4 rounded-2xl text-black outline-none"
            />

            <input
              type="tel"
              placeholder="Phone Number"
              className="p-4 rounded-2xl text-black outline-none"
            />

            <input
              type="email"
              placeholder="Email Address"
              className="p-4 rounded-2xl text-black outline-none"
            />

            <select className="p-4 rounded-2xl text-black outline-none">
              <option>Select Course</option>
              <option>Digital Marketing</option>
              <option>Spoken English</option>
              <option>Grooming</option>
              <option>Banking</option>
            </select>

            <textarea
              placeholder="Your Message"
              rows="5"
              className="md:col-span-2 p-4 rounded-2xl text-black outline-none"
            ></textarea>

            <button
              type="submit"
              className="md:col-span-2 bg-yellow-400 text-black font-bold py-4 rounded-2xl"
            >
              Submit Registration
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-950 text-white py-8 text-center">
        <p className="text-lg font-medium">
          © 2026 Northstar Job Excellence Academy. All Rights Reserved.
        </p>
      </footer>
    </div>
  );
}
